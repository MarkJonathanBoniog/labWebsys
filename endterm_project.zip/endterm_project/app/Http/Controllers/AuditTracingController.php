<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuditTracingController extends Controller
{
    //
}
