

<?php $__env->startSection('title', 'Record List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3 class="mb-4">Record List</h3>
    
    <a href="<?php echo e(route('staff.record.generate')); ?>" class="btn btn-success mb-4">Create new record</a>

    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('records.index')); ?>" class="row g-3 mb-4">
        <div class="col-md-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['Pending', 'Ready', 'Completed', 'Failed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                        <?php echo e($status); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="program" class="form-label">Program</label>
            <select name="program" id="program" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($program); ?>" <?php echo e(request('program') == $program ? 'selected' : ''); ?>>
                        <?php echo e($program); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="year" class="form-label">Year</label>
            <select name="year" id="year" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($year); ?>" <?php echo e(request('year') == $year ? 'selected' : ''); ?>>
                        <?php echo e($year); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
        </div>
    </form>

    <!-- Record Table -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Reference Number</th>
                    <th>Transferee Name</th>
                    <th>Program</th>
                    <th>Status</th>
                    <th>Handled By</th>
                    <th>Claimed At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $badgeClass = match ($record->status) {
                            'Pending' => 'secondary',
                            'Ready' => 'warning',
                            'Completed' => 'success',
                            'Failed' => 'danger',
                            default => 'light'
                        };
                        $recordUrl = route('staff.record.view', Crypt::encrypt($record->id));
                    ?>
                    <tr class="clickable-row" data-href="<?php echo e($recordUrl); ?>" style="cursor: pointer;">
                        <td><?php echo e($record->refnumber); ?></td>
                        <td><?php echo e($record->lname); ?>, <?php echo e($record->fname); ?> <?php echo e($record->mname); ?></td>
                        <td><?php echo e($record->program); ?></td>
                        <td><span class="badge bg-<?php echo e($badgeClass); ?>"><?php echo e($record->status); ?></span></td>
                        <td><?php echo e($record->user->fname); ?> <?php echo e($record->user->lname); ?></td>
                        <td><?php echo e($record->claimed ? \Carbon\Carbon::parse($record->claimed)->format('F j, Y g:i A') : ($record->status == "Failed" ? 'Unavailable' : 'Not Yet')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($records->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.clickable-row').forEach(function(row) {
                row.addEventListener('click', function (e) {
                    // prevent clicks on buttons/links from triggering row click
                    if (e.target.tagName.toLowerCase() !== 'a' && e.target.tagName.toLowerCase() !== 'button') {
                        window.location = this.dataset.href;
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\endterm_project\resources\views/staff/index.blade.php ENDPATH**/ ?>