

<?php $__env->startSection('title', 'Record View'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-4">
<a href="<?php echo e(route('records.index')); ?>" class="btn btn-secondary mb-4">
    &#8592; Back to Record List
</a>

<h2>Record View</h2>

<?php if($record->number && $record->refnumber): ?>
    <div class="row g-3 mb-4">
        
        <div class="col-md-4">
            <div class="card text-dark" style="background-color: #d0e7ff;">
                <div class="card-body">
                    <h6 class="card-title mb-1">Date Requested</h6>
                    <p class="card-text fw-bold"><?php echo e($record->created_at->format('F j, Y g:i A')); ?></p>
                </div>
            </div>
        </div>

        
        <div class="col-md-3">
            <div class="card text-dark bg-info bg-opacity-25">
                <div class="card-body">
                    <h6 class="card-title mb-1">Reference Number</h6>
                    <p class="card-text fw-bold"><?php echo e($record->refnumber); ?></p>
                </div>
            </div>
        </div>

        
        <div class="col-md-5">
            <?php
                $status = strtolower($record->status);
                $statusColor = match($status) {
                    'pending' => 'secondary',
                    'ready' => 'warning',
                    'completed' => 'success',
                    'failed' => 'danger',
                    default => 'light'
                };
            ?>

            <div class="card text-dark bg-<?php echo e($statusColor); ?> bg-opacity-25">
                <div class="card-body">
                    <h6 class="card-title mb-1">Status</h6>
                    <p class="card-text fw-bold text-dark">
                    <?php if($record->status == "Failed"): ?>
                        <?php echo e($record->status); ?> at <?php echo e($record->updated_at->format('F j, Y g:i A')); ?>

                    <?php elseif($record->status == "Completed"): ?>
                        <?php echo e($record->status); ?> at <?php echo e($record->claimed->format('F j, Y g:i A')); ?>

                    <?php else: ?> 
                        <?php echo e($record->status); ?> | Last edited: <?php echo e($record->updated_at->format('F j, Y g:i A')); ?>

                    <?php endif; ?> 
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($readonly): ?>
    <div class="alert alert-warning"><?php echo e($message); ?></div>
<?php endif; ?>

<h4 id="section1">Basic Information</h4>
<?php if(session('success1')): ?>
    <div class="alert alert-success"><?php echo e(session('success1')); ?></div>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('record.update.basic', $record->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group mb-3">
        <label>Firstname</label>
        <input class="form-control" name="fname" value="<?php echo e($record->fname); ?>" <?php echo e($readonly ? 'readonly' : ''); ?>>
        <?php if($errors->has('fname')): ?>
            <div class="alert alert-danger mt-2"><?php echo e($errors->first('fname')); ?></div>
        <?php endif; ?>
    </div>
    <div class="form-group mb-3">
        <label>Middlename</label>
        <input class="form-control" name="mname" value="<?php echo e($record->mname); ?>" <?php echo e($readonly ? 'readonly' : ''); ?>>
        <?php if($errors->has('mname')): ?>
            <div class="alert alert-danger mt-2"><?php echo e($errors->first('mname')); ?></div>
        <?php endif; ?>
    </div>
    <div class="form-group mb-3">
        <label>Lastname <small>(with suffix, if any)</small></label>
        <input class="form-control" name="lname" value="<?php echo e($record->lname); ?>" <?php echo e($readonly ? 'readonly' : ''); ?>>
        <?php if($errors->has('lname')): ?>
            <div class="alert alert-danger mt-2"><?php echo e($errors->first('lname')); ?></div>
        <?php endif; ?>
    </div>
    <div class="form-group mb-3">
        <label>Program</label>
        <select class="form-control" name="program" <?php echo e(($record->number && $record->refnumber) || $readonly ? 'disabled' : ''); ?>>
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($program); ?>" <?php echo e($record->program == $program ? 'selected' : ''); ?>><?php echo e($program); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($errors->has('program')): ?>
            <div class="alert alert-danger mt-2"><?php echo e($errors->first('program')); ?></div>
        <?php endif; ?>
        <?php if($record->number && $record->refnumber): ?>
            <small class="form-text text-muted">Program is locked after reference number is confirmed and generated.</small>
            <input type="hidden" name="program" value="<?php echo e($record->program); ?>">
        <?php endif; ?>
    </div>
    <?php if (! ($readonly)): ?>
        <button type="submit" class="btn btn-primary mt-2">Save Information</button>
    <?php endif; ?>
</form>

<?php if($record->number && $record->refnumber): ?>
    <hr class="my-4">
    <h4 id="section2" class="mb-3">Document Submission</h4>
    <?php if(session('success2')): ?>
        <div class="alert alert-success"><?php echo e(session('success2')); ?></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('record.update.documents', $record->id)); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" name="hasOtr" id="hasOtr" value="1" <?php echo e($record->hasOtr ? 'checked' : ''); ?> <?php echo e($readonly ? 'disabled' : ''); ?>>
            <label class="form-check-label" for="hasOtr">Has Official Transcript of Records (OTR)</label>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="hasForm" id="hasForm" value="1" <?php echo e($record->hasForm ? 'checked' : ''); ?> <?php echo e($readonly ? 'disabled' : ''); ?>> 
            <label class="form-check-label" for="hasForm">Has Form 137</label>
        </div>

        <?php if($errors->has("hasOtr") || $errors->has("hasForm")): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (! ($readonly)): ?>
            <button type="submit" class="btn btn-primary">Save Document Status</button>
        <?php endif; ?>
    </form>
<?php endif; ?>

<?php if($record->hasOtr && $record->hasForm): ?>
    <hr class="my-4">
    <h4 id="section3" class="mt-5">Transfer Credential Information</h4>
    <?php if(session('success3')): ?>
        <div class="alert alert-success"><?php echo e(session('success3')); ?></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('record.update.transfer_info', $record->id)); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label>Address</label>
            <input type="text" name="address" class="form-control"
                value="<?php echo e(old('address', $record->address)); ?>"
                <?php echo e($readonly ? 'readonly' : ''); ?> required>
            <?php if($errors->has('address')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('address')); ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-group mb-3">
            <label>Sex</label><br>
            <?php $__currentLoopData = ['Male', 'Female', 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                    <input type="radio" name="sex" value="<?php echo e($sex); ?>"
                        <?php echo e($record->sex === $sex ? 'checked' : ''); ?>

                        <?php echo e($readonly ? 'disabled' : ''); ?>> <?php echo e($sex); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($errors->has('sex')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('sex')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <label>Semester</label><br>
            <?php $__currentLoopData = ['1st', '2nd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                    <input type="radio" name="semester" value="<?php echo e($sem); ?>"
                        <?php echo e($record->semester === $sem ? 'checked' : ''); ?>

                        <?php echo e($readonly ? 'disabled' : ''); ?>> <?php echo e($sem); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($errors->has('semester')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('semester')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <label>Academic Year</label>
            <select name="schoolyear" class="form-control" <?php echo e($readonly ? 'disabled' : ''); ?>>
                <?php $__currentLoopData = $schoolYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sy); ?>" <?php echo e($record->schoolyear === $sy ? 'selected' : ''); ?>>
                        <?php echo e($sy); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('schoolyear')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('schoolyear')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <label>Transfer From</label>
            <input type="text" name="transferfrom" class="form-control"
                value="<?php echo e(old('transferfrom', $record->transferfrom)); ?>"
                <?php echo e($readonly ? 'readonly' : ''); ?>>
            <?php if (! ($readonly)): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary mt-1"
                    onclick="document.querySelector('[name=transferfrom]').value='Pangasinan State University - Urdaneta City Campus'">
                    This University
                </button>
            <?php endif; ?>
            <?php if($errors->has('transferfrom')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('transferfrom')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <label>Transfer To</label>
            <input type="text" name="transferto" class="form-control"
                value="<?php echo e(old('transferto', $record->transferto)); ?>"
                <?php echo e($readonly ? 'readonly' : ''); ?>>
            <?php if (! ($readonly)): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary mt-1"
                    onclick="document.querySelector('[name=transferto]').value='Pangasinan State University - Urdaneta City Campus'">
                    This University
                </button>
            <?php endif; ?>
            <?php if($errors->has('transferto')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('transferto')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <input id="isUndergradCheckbox" class="form-check-input" type="checkbox" name="isUndergrad" value="1"
                <?php echo e($record->isUndergrad ? 'checked' : ''); ?>

                <?php echo e($readonly ? 'disabled' : ''); ?>

                onchange="toggleGraduationField()" id="isUndergradCheckbox">
            <label class="form-check-label" for="isUndergradCheckbox">Is Undergraduate?</label>
        </div>

        <div class="form-group mb-4" id="graduationYearGroup" <?php if($record->isUndergrad): ?> style="display: none;" <?php endif; ?>>
            <label>Year Graduated</label>
            <input type="number" name="yearGraduated" class="form-control"
                value="<?php echo e(old('yearGraduated', $record->yearGraduated)); ?>"
                <?php echo e($readonly ? 'readonly' : ''); ?>

                min="1950" max="<?php echo e(now()->year); ?>">
            <?php if($errors->has('yearGraduated')): ?>
                <div class="alert alert-danger mt-2"><?php echo e($errors->first('yearGraduated')); ?></div>
            <?php endif; ?>
        </div>
        <?php if (! ($readonly)): ?>
            <button type="submit" class="btn btn-success mt-2">Save Information</button>
        <?php endif; ?>
    </form>
<?php endif; ?>
<?php if($record->status === 'Pending' && !$readonly && $record->refnumber): ?>
    <?php if($record->status !== 'Completed'): ?>
    <hr class="my-4">
    <div class="d-flex justify-content-center gap-3 mb-3" style="max-width: 200px; margin: 0 auto;">
        <form action="<?php echo e(route('record.invalidate', Crypt::encrypt($record->id))); ?>" method="post" class="flex-fill m-0">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <button type="submit" class="btn btn-outline-danger w-100">Invalidate Record</button>
        </form>
    </div>
    <?php endif; ?>
<?php endif; ?>
<?php if($record->status === 'Ready' || ($readonly && $record->status === 'Completed')): ?>
    <hr class="my-4">
    <div class="d-flex justify-content-center gap-3 mb-3" style="max-width: 800px; margin: 0 auto;">
    <a href="<?php echo e(route('certificate.preview', Crypt::encrypt($record->id))); ?>" 
   target="_blank" 
   class="btn btn-outline-warning flex-fill text-center">
    Preview Certificate
    </a>
    <a href="<?php echo e(route('certificate.print', Crypt::encrypt($record->id))); ?>" 
   class="btn btn-outline-primary flex-fill text-center">
    Print Certificate
    </a>
    <?php if(!$readonly): ?>
        
        <?php if($record->status !== 'Completed' || $record->status !== 'Failed'): ?>
            <form action="<?php echo e(route('record.complete', Crypt::encrypt($record->id))); ?>" method="post" class="flex-fill m-0">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <button type="submit" class="btn btn-outline-success w-100">Complete Transaction</button>
            </form>
        <?php endif; ?>

        
        <?php if($record->status !== 'Completed'): ?>
            <form action="<?php echo e(route('record.invalidate', Crypt::encrypt($record->id))); ?>" method="post" class="flex-fill m-0">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <button type="submit" class="btn btn-outline-danger w-100">Invalidate Record</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function toggleGraduationField() {
            const checkbox = document.getElementById('isUndergradCheckbox');
            const group = document.getElementById('graduationYearGroup');
            group.style.display = checkbox.checked ? 'none' : 'block';
        }
        document.addEventListener('DOMContentLoaded', toggleGraduationField);
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\labWebsys\endterm_project\resources\views/staff/record_view.blade.php ENDPATH**/ ?>