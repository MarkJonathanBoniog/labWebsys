

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Audit Tracing</h3>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\endterm_project\resources\views/staff/auditStaff.blade.php ENDPATH**/ ?>