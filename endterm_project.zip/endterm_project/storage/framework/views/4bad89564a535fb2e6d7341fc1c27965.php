

<?php $__env->startSection('title', 'Record List'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <h3 class="mb-4">Record List</h3>
    
    <p>Monitor and manage all records made on the system as an administrator.</p>

    <hr class="mx-2">

    <h5>Filtering Options</h5>
    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('admin.index')); ?>" class="row g-3 mb-4">
        <div class="col-md-12">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(request('name')); ?>" placeholder="Search by recepient's name">
        </div>
        <div class="col-md-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['Pending', 'Ready', 'Completed', 'Failed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                        <?php echo e($status); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="program" class="form-label">Program</label>
            <select name="program" id="program" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($program); ?>" <?php echo e(request('program') == $program ? 'selected' : ''); ?>>
                        <?php echo e($program); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="from_date" class="form-label">From Date</label>
            <input type="date" name="from_date" id="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
        </div>
        <div class="col-md-3">
            <label for="to_date" class="form-label">To Date</label>
            <input type="date" name="to_date" id="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
        </div>
        <div class="col-12">
            <a href="#" class="text-primary" onclick="event.preventDefault(); document.getElementById('advanced-filters').classList.toggle('d-none');">
                Toggle Advanced Filters
            </a>
        </div>
        <?php
            $advancedVisible = request()->filled('semester') || request()->filled('gender') || request()->filled('schoolyear') || request()->filled('staff');
        ?>
        <div id="advanced-filters" class="row g-3 mt-2 <?php echo e($advancedVisible ? '' : 'd-none'); ?>">
            <div class="col-md-3">
                <label for="semester" class="form-label">Semester</label>
                <select name="semester" id="semester" class="form-select">
                    <option value="">All</option>
                    <option value="1st" <?php echo e(request('semester') == '1st' ? 'selected' : ''); ?>>1st</option>
                    <option value="2nd" <?php echo e(request('semester') == '2nd' ? 'selected' : ''); ?>>2nd</option>
                </select>
            </div>

            <div class="col-md-3">
                <label for="gender" class="form-label">Gender</label>
                <select name="gender" id="gender" class="form-select">
                    <option value="">All</option>
                    <?php $__currentLoopData = ['Male', 'Female', 'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gender); ?>" <?php echo e(request('gender') == $gender ? 'selected' : ''); ?>><?php echo e($gender); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="schoolyear" class="form-label">Academic Year</label>
                <select name="schoolyear" id="schoolyear" class="form-select">
                    <option value="">All</option>
                    <?php for($y = 2025; $y >= 1950; $y--): ?>
                        <?php $pair = $y . '-' . ($y + 1); ?>
                        <option value="<?php echo e($pair); ?>" <?php echo e(request('schoolyear') == $pair ? 'selected' : ''); ?>><?php echo e($pair); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="staff" class="form-label">Handled By (Staff)</label>
                <select name="staff" id="staff" class="form-select">
                    <option value="">All</option>
                    <?php $__currentLoopData = $staffUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($staff->id); ?>" <?php echo e(request('staff') == $staff->id ? 'selected' : ''); ?>>
                            <?php echo e($staff->fname); ?> <?php echo e($staff->lname); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
        </div>
    </form>

    <!-- Record Table -->
    <hr id="list">
    <h5>Record Listing</h5>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Reference Number</th>
                    <th>Transferee Name</th>
                    <th>Program</th>
                    <th>Handled By</th>
                    <th>Year</th>
                    <th>Date Requested</th>
                    <th>Status</th>
                    <th>Claimed At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $badgeClass = match ($record->status) {
                            'Pending' => 'secondary',
                            'Ready' => 'warning',
                            'Completed' => 'success',
                            'Failed' => 'danger',
                            default => 'light'
                        };
                        $recordUrl = route('staff.record.view', Crypt::encrypt($record->id));
                    ?>
                    <tr class="clickable-row" data-href="<?php echo e($recordUrl); ?>" style="cursor: pointer;">
                        <td><?php echo e($record->refnumber); ?></td>
                        <td><?php echo e($record->lname); ?>, <?php echo e($record->fname); ?> <?php echo e($record->mname); ?></td>
                        <td><?php echo e($record->program); ?></td>
                        <td><?php echo e($record->user->fname); ?> <?php echo e($record->user->lname); ?></td>
                        <td><?php echo e($record->schoolyear); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($record->created_at)->format('F j, Y g:i A')); ?></td>
                        <td><span class="badge bg-<?php echo e($badgeClass); ?>"><?php echo e($record->status); ?></span></td>
                        <td><?php echo e($record->claimed ? \Carbon\Carbon::parse($record->claimed)->format('F j, Y g:i A') : ($record->status == "Failed" ? 'Unavailable' : 'Not Yet')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($records->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        // Make rows clickable
        document.querySelectorAll('.clickable-row').forEach(function(row) {
            row.addEventListener('click', function (e) {
                if (e.target.tagName.toLowerCase() !== 'a' && e.target.tagName.toLowerCase() !== 'button') {
                    window.location = this.dataset.href;
                }
            });
        });

        // Scroll to #list if filters were applied
        const url = new URL(window.location.href);
        const hasParams = url.searchParams.toString().length > 0;

        if (hasParams && document.getElementById('list')) {
            document.getElementById('list').scrollIntoView({ behavior: 'smooth' });
        }
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\labWebsys\endterm_project\resources\views/admin/index.blade.php ENDPATH**/ ?>