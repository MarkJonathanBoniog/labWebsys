

<?php $__env->startSection("title", "Staff Audit Tracing"); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <h3>Staff Audit Tracing</h3>
    <h5>Administrator Access for All Transfer Credential Reports of All Staff</h5>
    
    <hr>
    <p>This page will automatically generate a <strong>Transferees Report File</strong>. Filter out the details of the summary report. All fields are required.</p>
    <form action="<?php echo e(route('admin.auditTracing.result')); ?>" method="GET" target="_blank">
        <?php echo csrf_field(); ?>
        
        <div class="mb-3">
            <label class="form-label"><strong>Staff</strong> <i>(defaulted to all staff)</i></label>
            <select name="staff_id" class="form-select">
                <option value="all">All Staff</option>
                <?php $__currentLoopData = $staffList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->fname); ?> <?php echo e($staff->lname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>All Records Requested on Academic Year</strong></label>
            <select name="year" class="form-select" required>
                <?php
                    $currentYear = now()->year;
                ?>

                <?php for($y = $currentYear; $y >= 1950; $y--): ?>
                    <option value="<?php echo e($y); ?>-<?php echo e($y + 1); ?>"><?php echo e($y); ?>-<?php echo e($y + 1); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>All Records Requested Between This Time Range</strong></label><br>
            <?php $__currentLoopData = ['Whole Year', 'First Half', 'Second Half', 'First Quarter', 'Second Quarter', 'Third Quarter', 'Fourth Quarter', 'Manual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="range" value="<?php echo e($r); ?>" required onchange="toggleManualRange(this)">
                    <label class="form-check-label"><?php echo e($r); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div id="manual-range" class="row g-3 d-none mt-1">
            <div class="col-md-6">
                <label><strong>From</strong></label>
                <input type="date" name="from" class="form-control">
            </div>
            <div class="col-md-6">
                <label><strong>To</strong></label>
                <input type="date" name="to" class="form-control">
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>Filter Records By Semester</strong></label>
            <select name="semester" class="form-select" required>
                <option value="1st">1st Semester</option>
                <option value="2nd">2nd Semester</option>
                <option value="both">Both</option>
            </select>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="include_genders" id="include_genders">
            <label class="form-check-label" for="include_genders"><strong>Include Genders Columns To The Table</strong></label>
        </div>

        <div class="d-flex justify-content-center gap-3 mb-3" style="max-width: 800px; margin: 0 auto;">
            <button type="submit" name="action" value="view" class="btn btn-primary">Preview Report</button>
            <button type="submit" name="action" value="pdf" class="btn btn-success">Download PDF</button>
        </div>
    </form>
<script>
function toggleManualRange(radio) {
    const manual = document.getElementById('manual-range');
    manual.classList.toggle('d-none', radio.value !== 'Manual');
}
</script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\labWebsys\endterm_project\resources\views/admin/auditAdmin.blade.php ENDPATH**/ ?>