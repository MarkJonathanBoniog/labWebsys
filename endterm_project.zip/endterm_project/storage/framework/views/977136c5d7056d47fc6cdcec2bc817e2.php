<div class="container">
    <h2>Register Staff</h2>

    <?php if(session('success')): ?>
        <div>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('register.staff.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div>
            <label for="fname">First Name</label>
            <input type="text" class="form-control" name="fname" value="<?php echo e(old('fname')); ?>" required>
        </div>

        <div>
            <label for="lname">Last Name</label>
            <input type="text" class="form-control" name="lname" value="<?php echo e(old('lname')); ?>" required>
        </div>

        <div>
            <label for="email">Email Address</label>
            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>

        <div>
            <label for="password">Password (min. 6 chars)</label>
            <input type="password" class="form-control" name="password" required>
        </div>

        <div>
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" name="password_confirmation" required>
        </div>

        <button type="submit">Register Staff</button>
    </form>
</div>

<a href="<?php echo e(route('login')); ?>">Go to login</a>
<?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\endterm_project\resources\views/users/register.blade.php ENDPATH**/ ?>