

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Dashboard</h3>
    <a href="<?php echo e(route('staff.record.generate')); ?>" class="btn btn-success mt-4">Create new record</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\endterm_project\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>