

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <h3>System Settings</h3>

    <hr class="mx-2">

    <div class="mb-5">
        <h5>Upload Header & Footer Images for PDF Documents</h5>

        <?php if(session('image_success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('image_success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->has('header') || $errors->has('footer')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <ul class="mb-0">
                    <?php if($errors->has('header')): ?>
                        <li><?php echo e($errors->first('header')); ?></li>
                    <?php endif; ?>
                    <?php if($errors->has('footer')): ?>
                        <li><?php echo e($errors->first('footer')); ?></li>
                    <?php endif; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.systemSettings.uploadImages')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <!-- Header Image (full width) -->
            <div class="mb-4">
                <label class="form-label">Header Image</label>
                <input type="file" name="header" class="form-control">
                <div class="mt-2">
                    <img src="<?php echo e($headerPath ?? 'https://via.placeholder.com/300x100?text=No+Header'); ?>" 
     alt="Header Preview" class="img-fluid border">
                </div>
            </div>

            <!-- Footer Image (full width) -->
            <div class="mb-4">
                <label class="form-label">Footer Image</label>
                <input type="file" name="footer" class="form-control">
                <div class="mt-2">
                    <img src="<?php echo e($footerPath ?? 'https://via.placeholder.com/300x100?text=No+Footer'); ?>" 
     alt="Footer Preview" class="img-fluid border">
                </div>
            </div>

            <!-- Submit Button (centered) -->
            <div class="text-center">
                <button type="submit" class="btn btn-primary px-5">Upload Images</button>
            </div>
        </form>
    </div>

    <hr id="progs" class="mx-2">

    <h5>Manage Programs</h5>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('admin.program.store')); ?>" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="row g-2">
            <div class="col-md-4">
                <input type="text" name="abbrev" class="form-control <?php $__errorArgs = ['abbrev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Abbreviation" value="<?php echo e(old('abbrev')); ?>" required>
            </div>
            <div class="col-md-6">
                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Program Name" value="<?php echo e(old('name')); ?>" required>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Add</button>
            </div>
        </div>
    </form>

    
    <table class="table table-bordered table-hover">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Abbreviation</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <form method="POST" action="<?php echo e(route('admin.program.update', $program->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <td><?php echo e($index + 1); ?></td>
                        <td><input type="text" name="abbrev" value="<?php echo e(old('abbrev', $program->abbrev)); ?>" class="form-control" required></td>
                        <td><input type="text" name="name" value="<?php echo e(old('name', $program->name)); ?>" class="form-control" required></td>
                        <td class="d-flex gap-2">
                            <button type="submit" class="btn btn-sm btn-success">Update</button>
                    </form>
                            <form method="POST" action="<?php echo e(route('admin.program.destroy', $program->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center">No programs found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\labWebsys\endterm_project\resources\views/admin/systemSettings.blade.php ENDPATH**/ ?>