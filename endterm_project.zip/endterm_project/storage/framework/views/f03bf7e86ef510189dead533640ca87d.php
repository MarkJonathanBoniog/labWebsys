<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <link href="<?php echo e(asset('vendor/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            overflow-x: auto; /* Enable horizontal scroll */
        }

        .fixed-layout {
            width: 1248px;
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #f4f4f4;
            padding: 20px;
            border-right: 1px solid #ccc;
        }

        .content-wrapper {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: #eee;
            padding: 15px 20px;
            border-bottom: 1px solid #ccc;
        }

        .main-content {
            padding: 20px;
            flex: 1;
            overflow-y: auto;
        }


        .sidebar h3 {
            margin-top: 0;
        }

        .sidebar a {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            text-decoration: none;
            color: #333;
        }

        .sidebar a:hover {
            background-color: #ddd;
        }

        .nav-link.active {
            font-weight: bold;
            color: #0d6efd;
            background-color: #e7f1ff;
            border-radius: 4px;
        }
    </style>
</head>
<body style="margin: 0; overflow-x: auto;">
    <div class="fixed-layout">

        <!-- Sidebar -->
        <div class="sidebar">
            <h4>Tranfer Credential System</h4>
            <ul class="nav flex-column">
                <?php if(Auth::user()->role == "staff"): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('staff.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('staff.dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('records.index') ? 'active' : ''); ?>" href="<?php echo e(route('records.index')); ?>">Record List</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('staff.audit') ? 'active' : ''); ?>" href="<?php echo e(route('staff.audit')); ?>">Audit Tracing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('staff.settings') ? 'active' : ''); ?>" href="<?php echo e(route('staff.settings')); ?>">User Settings</a>
                </li>
                <?php endif; ?>

                <?php if(Auth::user()->role == "admin"): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('admin.records') ? 'active' : ''); ?>" href="#">Record List</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('admin.audit') ? 'active' : ''); ?>" href="#">Staff Audit Tracing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('admin.programs') ? 'active' : ''); ?>" href="#">Manage Programs</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::is('admin.settings') ? 'active' : ''); ?>" href="#">User Settings</a>
                </li>
                <?php endif; ?>

                <li class="nav-item mt-3">
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger w-100" type="submit">Logout</button>
                    </form>
                </li>
            </ul>
        </div>

        <!-- Content -->
        <div class="content-wrapper">
            <div class="header d-flex justify-content-between align-items-start">
                <div>
                    <div><strong>Welcome, <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?>!</strong></div>
                    <div>
                        Role: 
                        <?php if(Auth::user()->role == "admin"): ?>
                            Administrator
                        <?php else: ?>
                            Staff
                        <?php endif; ?>
                    </div>
                </div>
                <div id="current-time"></div>
            </div>


            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</body>
<script>
    function updateTime() {
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        };
        const now = new Date();
        const formattedTime = now.toLocaleString('en-US', options);
        document.getElementById('current-time').textContent = formattedTime;
    }

    setInterval(updateTime, 1000);
    updateTime(); // Initial call
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</html>
<?php /**PATH C:\Yatchin\xammp\htdocs\markjonathanboniog-rep-elec1-3a\final_project\endterm_project\resources\views/layouts/main.blade.php ENDPATH**/ ?>